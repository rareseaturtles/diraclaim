---
'@solana/rpc-subscriptions-channel-websocket': patch
'@solana/transaction-confirmation': patch
'@solana/rpc-subscriptions-spec': patch
'@solana/rpc-subscriptions': patch
'@solana/subscribable': patch
'@solana/rpc': patch
---

Disabled the `MaxListenersExceededWarning` in Node when creating event targets for internal use
