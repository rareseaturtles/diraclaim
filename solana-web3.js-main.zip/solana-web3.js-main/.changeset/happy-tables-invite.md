---
'@solana/compat': patch
---

yAdded a helper to convert legacy `TransactionInstruction` objects to modern `IInstruction` objects
