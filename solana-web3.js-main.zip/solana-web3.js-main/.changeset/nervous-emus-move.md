---
'@solana/rpc-types': patch
'@solana/accounts': patch
---

Add missing `space` attribute to `AccountInfoBase` and `BaseAccount`
