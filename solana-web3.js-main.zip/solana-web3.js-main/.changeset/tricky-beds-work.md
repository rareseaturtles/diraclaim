---
'@solana/web3.js': patch
---

Add a new function `fetchAddressesForLookupTables` to fetch the addresses contained in a list of lookup tables'
