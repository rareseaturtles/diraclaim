---
'@solana/sysvars': minor
---

Removed the fees sysvar which has been disabled on the network for a year, and has now been removed from the test validator in Agave 2.0

```
% solana feature status JAN1trEUEtZjgXYzNBYHU9DYd7GnThhXfFP7SzPXkPsG
Feature                                      | Status                  | Activation Slot | Description
JAN1trEUEtZjgXYzNBYHU9DYd7GnThhXfFP7SzPXkPsG | active since epoch 483  | 208656004       | disable fees sysvar
```
