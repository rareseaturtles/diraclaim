---
'@solana/addresses': minor
---

Add getPublicKeyFromAddress to derive public keys from addresses
