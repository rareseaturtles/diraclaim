---
name: Suggest a Feature
about: Propose an idea for how to make this library better.
title: ''
labels: ['enhancement']
assignees: ''
---

<!-- Please fill in each section completely. Thank you! -->

## Motivation

<!--
  Say a few words about what motivated you to propose this enhancement.
-->

## Example use case

<!--
  Demonstrate how someone might use this new feature.

  If applicable, write code or pseudocode that would produce the
  desired result if this feature existed.
-->

## Details

<!--
  Go into detail about how this new feature must behave. If you have
  ideas on how to implement it, go into them here.
-->
