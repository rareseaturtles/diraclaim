export const AbortController = globalThis.AbortController;
export const EventTarget = globalThis.EventTarget;
