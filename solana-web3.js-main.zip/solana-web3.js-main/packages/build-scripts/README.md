# `build-scripts`

This is the base build script shared across all packages in this monorepo.
