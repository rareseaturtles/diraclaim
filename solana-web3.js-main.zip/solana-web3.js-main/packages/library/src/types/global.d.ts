declare const __BROWSER__: boolean;
declare const __DEV__: boolean;
declare const __NODEJS__: boolean;
declare const __REACTNATIVE__: boolean;
declare const __VERSION__: string;
