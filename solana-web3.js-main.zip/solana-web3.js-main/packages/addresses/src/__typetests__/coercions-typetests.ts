import { Address, address } from '../address';

address('555555555555555555555555') satisfies Address<'555555555555555555555555'>;
