export default globalThis.crypto;
